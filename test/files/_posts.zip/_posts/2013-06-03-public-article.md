---
layout: post
title: Public Article
category: Ruby
published: true
---

Public content
